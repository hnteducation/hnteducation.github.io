// Không tạo widget nhiều lần
if (!document.getElementById("auto-click-widget")) {

    const widget = document.createElement("div");
    widget.id = "auto-click-widget";
widget.innerHTML=`
<div id="auto-header">
    <span>🩺 Hỗ trợ khám</span>
    <span id="toggle">─</span>
</div>

<div id="auto-body">
    <div class="panel-title">
        ĐỀ NGHỊ
    </div>

    <div class="button-grid" id="suggestButtons"></div>

    <div class="panel-title">
        THAO TÁC
    </div>

    <div class="button-grid" id="actionButtons"></div>



</div>
`;

document.body.appendChild(widget);
    // ============================
    // Nút 1: Chọn "Không có"
    // ============================
    const btn = document.createElement("button");
    btn.id = "auto-click-btn";
    btn.textContent = "Đánh giá tâm thần";
    document
    .getElementById("actionButtons")
    .appendChild(btn);

    // ============================
    // Nút 2: Chọn Bình thường
    // ============================
    const btnNormal = document.createElement("button");
    btnNormal.id = "normal-btn";
    btnNormal.textContent = "Khám lâm sàng";
    document
    .getElementById("actionButtons").appendChild(btnNormal);

    // ============================
    // Nút 3: Lưu thay đổi
    // ============================
    const btnSave = document.createElement("button");
    btnSave.id = "save-btn";
    btnSave.textContent = "Lưu thay đổi";
    document
    .getElementById("actionButtons").appendChild(btnSave);

///
///
///
const btnInfo = document.createElement("button");
btnInfo.textContent = "Thông tin";
document.getElementById("actionButtons").appendChild(btnInfo);

btnInfo.addEventListener("click", fillThongTin);
///
///
///
async function fillThongTin() {

    await selectDxByTyping(
    "DoiTuong_M13",
    "Trẻ từ đủ 6 tuổi đến 18 tuổi đi học (lớp 1 đến lớp 12)"
);

await selectDxByTyping(
    "DoiTuongKham",
    "Khám lưu động"
);

await selectDxByTyping(
    "DanTocId",
    "Kinh"
);

await selectRadio(
    "TreEm_DangDiHoc",
    "Có"
);

await selectDxByTyping(
    "TreEm_XaPhuong",
    "Xã Hóc Môn"
);

await selectDxByTyping(
    "TreEm_TruongHocId",
    "THCS Nguyễn An Khương - Xã Hóc Môn"
);

    setHtmlEditor(
        "LyDoKhamSK",
        "Định kỳ"
    );

    await sleep(200);

    checkByText("Ngân sách thành phố hỗ trợ");

    await sleep(100);

    checkByText("Khám theo hợp đồng");

    console.log("Đã điền xong thông tin.");
}
async function checkByText(text){

    const item=[...document.querySelectorAll("*")].find(
        e=>e.textContent.trim()===text
    );

    if(!item)return;

    const row=item.closest(".dx-item") ||
              item.closest(".dx-field-item") ||
              item.parentElement;

    if(!row)return;

    const check=row.querySelector(".dx-checkbox-icon,.dx-radiobutton-icon");

    if(check){

        check.click();

        await sleep(150);

    }

}
async function selectDxByTyping(className, text) {

    const container = document.querySelector("." + className);

    if (!container) {
        console.log("Không tìm thấy:", className);
        return false;
    }

    const input = container.querySelector("input.dx-texteditor-input");

    if (!input) {
        console.log("Không tìm thấy input:", className);
        return false;
    }

    // Focus
    input.focus();

    // Xóa giá trị cũ
    input.value = "";

    input.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        inputType: "deleteContentBackward",
        data: null
    }));

    await sleep(100);

    // Nhập giá trị mới
    input.value = text;

    input.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        inputType: "insertText",
        data: text
    }));

    input.dispatchEvent(new Event("change", {
        bubbles: true
    }));

    await sleep(300);

    // Enter
    input.dispatchEvent(new KeyboardEvent("keydown", {
        key: "Enter",
        code: "Enter",
        keyCode: 13,
        which: 13,
        bubbles: true
    }));

    input.dispatchEvent(new KeyboardEvent("keyup", {
        key: "Enter",
        code: "Enter",
        keyCode: 13,
        which: 13,
        bubbles: true
    }));

    await sleep(300);

    return true;
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
function setupSyncPhone() {

    const sdtContainer = document.querySelector(".SDT");
    const guardianContainer = document.querySelector(".TreEm_SDT_NguoiGiamHo");

    if (!sdtContainer || !guardianContainer) {
        console.log("Không tìm thấy ô SDT.");
        return;
    }

    const sdtInput = sdtContainer.querySelector("input.dx-texteditor-input, input");
    const guardianInput = guardianContainer.querySelector("input.dx-texteditor-input, input");

    if (!sdtInput || !guardianInput) {
        console.log("Không tìm thấy input.");
        return;
    }

    // Tránh gắn nhiều lần
    if (sdtInput.dataset.syncGuardian === "1") return;
    sdtInput.dataset.syncGuardian = "1";

    sdtInput.addEventListener("blur", () => {

        const value = sdtInput.value.trim();

        guardianInput.focus();

        guardianInput.value = value;

        guardianInput.dispatchEvent(new InputEvent("input", {
            bubbles: true,
            inputType: "insertText",
            data: value
        }));

        guardianInput.dispatchEvent(new Event("change", {
            bubbles: true
        }));

        guardianInput.blur();

        console.log("Đã đồng bộ SĐT người giám hộ:", value);
    });

    console.log("Đã bật tự động đồng bộ SDT.");
}

const observer = new MutationObserver(() => {

    const sdt = document.querySelector(".SDT input");
    const guardian = document.querySelector(".TreEm_SDT_NguoiGiamHo input");

    if (!sdt || !guardian) return;

    if (sdt.dataset.syncGuardian) return;

    console.log("Gắn sự kiện SDT");

    setupSyncPhone();

});

observer.observe(document.body,{
    childList:true,
    subtree:true
});
async function selectRadio(className, text) {

    const container = document.querySelector("." + className);

    if (!container) {
        console.log("Không tìm thấy:", className);
        return false;
    }

    const items = [...container.querySelectorAll(".dx-radiobutton")];

    const item = items.find(i =>
        i.innerText.trim() === text
    );

    if (!item) {
        console.log("Không tìm thấy lựa chọn:", text);
        return false;
    }

    item.click();

    return true;
}

function setHtmlEditor(className, text) {

    const container = document.querySelector("." + className);

    if (!container) return;

    const editor = container.querySelector(".ql-editor");

    if (!editor) return;

    editor.focus();

    editor.innerHTML =
        `${text}`;

    editor.dispatchEvent(new InputEvent("input", {
        bubbles: true
    }));

    editor.dispatchEvent(new Event("change", {
        bubbles: true
    }));

    editor.blur();
}


//
//
//
function setSuggestion(text) {

    const editor = document.querySelector(".ql-editor");

    if (!editor) {
        console.log("Không tìm thấy ô Đề nghị");
        return;
    }

    editor.focus();

    editor.innerHTML = `<p><span style="font-family: Arial; font-size: 10pt;">${text}</span></p>`;

    editor.dispatchEvent(new InputEvent("input", {
        bubbles: true
    }));

    editor.dispatchEvent(new Event("change", {
        bubbles: true
    }));

    editor.dispatchEvent(new Event("blur", {
        bubbles: true
    }));
}
const suggestionButtons = [
    {
        title: "H52.2 H52.1",
        text: "Khám khúc xạ sau mỗi 6 tháng"
    },
    {
        title: "K02.8",
        text: "Khám chuyên khoa răng"
    },
    {
        title: "J02 J02.9",
        text: "Khám chuyên khoa tai mũi họng"
    },
    {
        title: "I10",
        text: "Kiểm tra huyết áp tại trạm y tế"
    },
    {
        title: "E11.9",
        text: "Kiểm tra đường huyết tại trạm y tế"
    },
    {
        title: "Loại I",
        text: "Kiểm tra sức khỏe định kỳ"
    }
];

suggestionButtons.forEach(item => {

    const b = document.createElement("button");

    b.textContent = item.title;

    b.addEventListener("click", () => {

        setSuggestion(item.text);

    });

    document
    .getElementById("suggestButtons").appendChild(b);

});

//
//
//
function setValue(selector, value) {

    const input = document.querySelector(selector + " input.dx-texteditor-input");

    if (!input) {
        console.log("Không tìm thấy:", selector);
        return;
    }

    input.focus();

    input.value = value;

    input.dispatchEvent(new Event("input", {
        bubbles: true
    }));

    input.dispatchEvent(new Event("change", {
        bubbles: true
    }));

    input.dispatchEvent(new Event("blur", {
        bubbles: true
    }));

}
    // =====================================================
    // Hàm click theo nội dung hiển thị
    // =====================================================
    function clickByText(text) {

        const elements = document.querySelectorAll("*");

        for (const el of elements) {

            if (el.textContent.trim() === text) {

                const target =
                    el.closest(".dx-checkbox") ||
                    el.closest(".dx-item") ||
                    el.closest("label") ||
                    el;

                target.click();
                return true;
            }
        }

        return false;
    }

function clickAllByText(text) {

    let count = 0;

    document.querySelectorAll("*").forEach(el => {

        if (el.textContent.trim() !== text) return;

        const container =
            el.closest(".dx-field") ||
            el.closest(".dx-item") ||
            el.closest(".dx-box-item") ||
            el.closest("tr") ||
            el.parentElement;

        if (!container) return;

        const checkbox =
            container.querySelector(".dx-checkbox-icon") ||
            container.querySelector(".dx-radiobutton-icon") ||
            container.querySelector(".dx-checkbox") ||
            container.querySelector("input[type=checkbox]") ||
            container.querySelector("label");

        if (checkbox) {
            checkbox.click();
            count++;
        } else {
            el.click();
            count++;
        }

    });

    console.log(text + ": " + count);

}

    // =====================================================
    // Nút "Không có"
    // =====================================================
    btn.addEventListener("click", () => {

        const items = document.querySelectorAll(
            "div.dx-item-content.dx-list-item-content"
        );

        let count = 0;

        items.forEach(item => {

            if (item.textContent.trim() === "Không có") {

                item.dispatchEvent(new MouseEvent("mouseover", {
                    bubbles: true
                }));

                item.click();

                item.dispatchEvent(new MouseEvent("mouseup", {
                    bubbles: true
                }));

                count++;
            }

        });

        console.log(`Đã click ${count} mục "Không có".`);
		const btnsave=document.querySelector('.btnTopReport ');
		btnsave.click();

    });

    // =====================================================
    // Nút Bình thường
    // =====================================================
    btnNormal.addEventListener("click", () => {

    clickAllByText("Chưa phát hiện bất thường");
    clickAllByText("Loại I");

    setValue(".TMH_TaiTrai_NoiThuong", "5");
    setValue(".TMH_TaiTrai_NoiTham", "0,5");

    setValue(".TMH_TaiPhai_NoiThuong", "5");
    setValue(".TMH_TaiPhai_NoiTham", "0,5");

});

    // =====================================================
    // Nút Lưu thay đổi
    // =====================================================
    btnSave.addEventListener("click", () => {

        // Cách 1: tìm theo class và text
        const save = [...document.querySelectorAll(".dx-button-content")]
            .find(el => el.textContent.includes("Lưu thay đổi"));

        if (save) {
            save.click();
            console.log("Đã bấm Lưu thay đổi");
            return;
        }

        // Dự phòng
        clickByText("Lưu thay đổi");

    });
///
///
///
const header=document.getElementById("auto-header");
const body=document.getElementById("auto-body");
const toggle=document.getElementById("toggle");

header.onclick=()=>{

    body.classList.toggle("hide");

    toggle.textContent=
        body.classList.contains("hide")
        ? "+"
        : "─";

};
}